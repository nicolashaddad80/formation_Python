import random


class Coque:

	def __init__(self, matiere, couleur, resistance, pdv=100):
		self.matiere = matiere
		self.couleur = couleur
		self.resistance = resistance
		self.pdv = pdv

	def is_en_vie(self):
		return self.pdv > 0

	def afficher_infos(self):
		return f"{self.matiere} - {self.couleur} \nRésistance : {self.resistance} \nPts de vie : {self.pdv} \n"

	def subir_degats(self, degats):
		self.pdv = max([0, self.pdv - degats])


class Arme:

	def __init__(self, nom, puis_tir, prix):
		self.nom = nom
		self.puis_tir = puis_tir
		self.prix = prix

	def afficher_infos(self):
		return f"{self.nom} - Puissance : {self.puis_tir} \n"


class Navire:

	def __init__(self, nom, coque, arme, kilometrage=0):
		self.nom = nom
		self.kilometrage = kilometrage
		self.coque = coque
		self.arme = arme

	def is_en_vie(self):
		return self.coque.is_en_vie()

	def afficher_infos(self):
		return f"[ {self.nom.upper()} ]\n" \
			f"{self.kilometrage} NM \n" \
			f"Coque : {self.coque.afficher_infos()}" \
			f"Arme : {self.arme.afficher_infos()}" \
			f"Etat : {'En vie' if self.is_en_vie() else 'Détruit'} \n" \
			f"------------------------- \n"

	def naviguer(self, distance):
		self.kilometrage += distance
		print(f"{self.nom} navigue, {distance} NM parcourus, km actuel : {self.kilometrage} NM")

	def tirer_sur(self, ennemi):
		rdm1 = random.random()
		rdm2 = random.random()
		rdm3 = random.random()

		degats = round((((0.5 + rdm1) * self.arme.puis_tir) - (rdm2 * ennemi.coque.resistance)) * rdm3)

		if degats > 0:
			print(f"{self.nom} tire sur {ennemi.nom}")
			ennemi.coque.subir_degats(degats)
			print(f"{ennemi.nom} subit {degats} dégâts, pts de vie : {ennemi.coque.pdv}")
		else:
			print(f"Le tir de {self.nom} a échoué")


if __name__ == '__main__':

	nav1 = Navire("Le titan", Coque("Métal", "Gris", 75.0), Arme("Canon", 80.0, 100000))
	nav2 = Navire("Le terrible", Coque("Métal", "Noir", 75.0), Arme("Canon", 75.0, 100000))
	nav3 = Navire("Le terrifiant", Coque("Métal", "Blanc", 70.0), Arme("Canon", 80.0, 100000))

	print(nav1.afficher_infos())

	nav2.naviguer(4000)
	nav2.naviguer(4000)

	nav1.tirer_sur(nav3)
	nav2.tirer_sur(nav3)
