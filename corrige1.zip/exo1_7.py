repertoire = {"01234": "John", "4567": "Jane", "7890": "Jack", "6543": "John"}

numero = input("Entrez un numéro : ")

if numero in repertoire:
	print(f"Le numéro {numero} appartient à {repertoire[numero]}")
else:
	print(f"Le numéro {numero} n'a pas été trouvé dans le répertoire")
	choix = input("Souhaitez-vous l'ajouter ? (O pour oui) ")
	if choix.lower() == 'o':
		nom = input(f"A qui appartient le numéro {numero} ?")
		repertoire[numero] = nom
		print(repertoire)
