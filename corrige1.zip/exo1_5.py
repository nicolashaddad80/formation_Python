nombre = input("Entrez un nombre : ")
nombre = int(nombre)

print("-- Carré 1 --")
for _ in range(nombre):
	print('*' * nombre)

print()
print("-- Carré 2 --")
print(f"{'*' * nombre}\n" * nombre)


print()
print("-- Triangle --")
for i in range(1, nombre+1):
	print('*' * i)
