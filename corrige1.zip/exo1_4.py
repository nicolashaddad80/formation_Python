nombres = [5, 96, -12, 1442, 0, 8, -123, 0, 55, -55, 0, 9, 5, 19, 18, -12, 66, 20, 4456, 1, 32, -4, 0, 8, 3, 53]
positifs = []

for n in nombres:
	print(n)
	if n >= 0:
		positifs.append(n)

print(positifs)
