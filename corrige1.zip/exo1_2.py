nom = input("Entrez votre nom : ")
age = input("Entrez votre âge : ")
age = int(age)

if age >= 18:
	print(f"{nom} est majeur")
else:
	print(f"{nom} est mineur")
