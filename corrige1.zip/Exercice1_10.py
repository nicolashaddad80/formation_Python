CODE = 9627
solde_actuel = 1847.33
code_bon = False
tentative = 1

while tentative <= 3 and not code_bon:
    # Tant qu'on a pas atteint 3 tentatives et que le code n'est toujours pas bon
    code_insere = int(input(f"\tVeuillez entrer vode code ({tentative}/3) > "))

    if code_insere == CODE:
        code_bon = True
        print("Code bon")

        while True:
            # Boucle infinie
            print("Que voulez-vous faire ?")
            print("1 : Consulter votre solde")
            print("2 : Effectuer un retrait")
            print("3 : Récupérer votre carte")
            choix = input("\tSélectionner une option [1-3] > ")

            if choix == "1":
                # Consulter le solde
                print("Votre solde actuel est", solde_actuel, "€")

            elif choix == "2":
                # Retirer
                print("Combien voulez vous retirer ?")
                somme = int(input("\tEntrez une somme (multiple de 10) > "))

                if somme % 10 == 0:
                    # Si la somme demandée est bien un multiple de 10
                    print(f"Vous avez demandé {somme}€")

                    if solde_actuel - somme >= 0:
                        # On vérifie si le solde est suffiant
                        solde_actuel -= somme
                        print("Veillez récupérer vos billets")

                    else:
                        print("Votre solde actuel ne vous permet pas de retirer cette somme")

                else:
                    print("Cette somme ne correspond pas à un multiple de 10")

            elif choix == "3":
                print("Veuillez reprendre votre carte")

                # On sort de la boucle infinie
                break
            else:
                # L'utilisateur a tapé autre chose que 1, 2 ou 3
                print("Choix non reconnu")

    else:
        # Mauvais code, on incrémente le nombre de tentatives
        tentative += 1
        print("Code erroné")
