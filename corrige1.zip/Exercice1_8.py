a = input("Entrez le a > ")
b = input("Entrez le b > ")
c = input("Entrez le c > ")

print(f"L'équation est {a}x² + {b}x + {c}")

a = int(a)
b = int(b)
c = int(c)

delta = (b ** 2) - (4 * a * c)
print("Le déterminant Δ est", delta)

if delta > 0:
    x1 = (-b - delta ** 0.5) / (2 * a)
    x2 = (-b + delta ** 0.5) / (2 * a)
    print("L'équation a deux solutions réelles")
    print("x1 = ", x1)
    print("x2 = ", x2)
elif delta == 0:
    x = -b / (2 * a)
    print("L'équation a une solution réelle")
    print("x = ", x)
else:
    print("L'équation n'a pas de solution réelle")
