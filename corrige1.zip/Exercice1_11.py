# -- Exercice 1.2
nom = input("Quel est votre nom ? > ")
age = input("Quel âge avez-vous ? > ")

if age.isnumeric():
    age = int(age)

    if age < 18:
        print(nom, "est mineur")
    else:
        print(nom, "est majeur")
else:
    print(age, "n'est pas un nombre")


# Exercice 1.3
nombre = input("Entrez un nombre > ")
if nombre.isnumeric():
    nombre = int(nombre)

    if nombre == 0:
        print(0, "est nul")
    elif nombre % 2 == 0:
        print(nombre, "est pair")
    else:
        print(nombre, "est impair")
else:
    print(nombre, "n'est pas un nombre")


# -- Exercice 1.5
nombre = input("Entrez un nombre > ")

if nombre.isnumeric():
    nombre = int(nombre)

    print("\n=== Triangle ===\n")
    triangle = ''
    for x in range(nombre):
        triangle += '*'
        print(triangle)

    print("\n=== Carré ===\n")
    for x in range(nombre):
        ligne = ""
        for y in range(nombre):
            ligne += '*'
        print(ligne)

    print("\n=== Triangle ===\n")
    for x in range(nombre):
        print("*" * (x + 1))

    print("\n=== Carré ===\n")
    for x in range(nombre):
        print("*" * nombre)
else:
    print(nombre, "n'est pas un nombre")


# -- Exercice 1.6
annee = input("Entrez une année > ")

if annee.isnumeric():
    annee = int(annee)

    if annee % 4 == 0 and annee % 100 != 0 or annee % 400 == 0:
        print(annee, "est bissextile")
    else:
        print(annee, "n'est pas bissextile")
else:
    print(annee, "n'est pas un nombre")


# -- Exercice 1.8
a = input("Entrez le a > ")
b = input("Entrez le b > ")
c = input("Entrez le c > ")

print(f"L'équation est {a}x² + {b}x + {c}")

if a.isnumeric() and b.isnumeric() and c.isnumeric():
    a = int(a)
    b = int(b)
    c = int(c)

    delta = (b ** 2) - (4 * a * c)
    print("Le déterminant Δ est", delta)

    if delta > 0:
        x1 = (-b - delta ** 0.5) / (2 * a)
        x2 = (-b + delta ** 0.5) / (2 * a)
        print("L'équation a deux solutions réelles")
        print("x1 = ", x1)
        print("x2 = ", x2)
    elif delta == 0:
        x = -b / (2 * a)
        print("L'équation a une solution réelle")
        print("x = ", x)
    else:
        print("L'équation n'a pas de solution réelle")
else:
    print("Une des valeurs entrées n'est pas un nombre")


# -- Exercice 1.9
nombre = input("Combien de termes de la suite de Fibonacci voulez-vous afficher ? > ")

if nombre.isnumeric():
    nombre = int(nombre)

    u0 = 0
    u1 = 1
    print(u0)
    print(u1)

    for x in range(nombre - 2):
        u2 = u0 + u1
        print(u2)
        u0 = u1
        u1 = u2
else:
    print(nombre, "n'est pas un nombre")
