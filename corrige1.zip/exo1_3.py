nombre = input("Entrez un nombre : ")
nombre = int(nombre)

if nombre == 0:
	print("Le nombre est nul")
elif nombre % 2 == 0:
	print(f"{nombre} est pair")
else:
	print(f"{nombre} est impair")
