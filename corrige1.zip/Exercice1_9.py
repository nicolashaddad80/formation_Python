nombre = input("Combien de termes de la suite de Fibonacci voulez-vous afficher ? > ")
nombre = int(nombre)

u0 = 0
u1 = 1
print(u0)
print(u1)

for x in range(nombre - 2):
    u2 = u0 + u1
    print(u2)
    u0, u1 = u1, u2
